/**

In this task you will implement the method histogramEqualization of the class Lab2_7 which will perform histogram equalization.  

The expected output is provided in the files solution1.png and solution2.png.

You may use the following command to check if your output is identical to ours. 

cmp solution1.png out.png

If this command has no output, it implies that your solution has produced the same file as ours.

**/

import java.util.Scanner;
public class Lab2_7 {
	public Lab2_7() {
		Img img = new Img("Fig03161.png");
		//Img img2 = new Img("solution1.png");
		//histogramEqualization(img, img2);
		histogramEqualization(img);
		img.save("out1.png");
		
		histogramEqualization(img);		
		img = new Img("HawkesBay.png");
		histogramEqualization(img);
		img.save("out2.png");
	}

	public void histogramEqualization(Img i) {
		//Your code here
		int[] histogram = new int[256];
		float[] returnValue = new float[256];
		
        for (int x = 0; x < i.img.length; x++){
            histogram[ (int)i.img[x] & 0xFF ]++;
		}
		
		int totalpixles = i.width*i.height;
		
		for (int x = 0; x < 256; x++){
			for (int y = 0; y <= x; y++){
				returnValue[x] += histogram[y];
			}
			returnValue[x] = returnValue[x]/(float)(totalpixles);
			//System.out.println("b[ "+ x + "] = "+ returnValue[x]);
		}

		for (int x = 0; x < 256; x++)
		{	
			int zs = (int)Math.floor(255.0*returnValue[x]);	
			float res = (float)255.0*returnValue[x] - zs ;
			if (res >= 0.5) 
				histogram[x] = zs + 1;
			else
				histogram[x] = zs;
			//histogram[x] = (int)Math.rint(255.0*returnValue[x]);
			//System.out.println("b[ "+ x + "] = "+ histogram[x]);
		}
		
		// lookup table
		for (int x = 0; x < i.img.length; x++) {
                i.img[x] = (byte)(histogram[i.img[x] & 0xFF]);
				//i.img[x] -= ii2.img[x];
				//if ((i.img[x]&0xFF) != 0)
				//	System.out.println("b: "+ i.img[x]);
        }
	}
		
	public static void main(String[] args) {
		new Lab2_7();
	}
}
