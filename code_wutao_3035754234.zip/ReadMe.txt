The source code includes 10 parts, each of which are lcoated in one folder. The items from 6) to 10) are wholely or partly implemented by myself.
1）tiling：Adjust tile size in M and N dimension
2）batching：Group tiles into one kernel
3）magma：The baseline to compare the performance
4）data：Generate matrix sizes
5）google-net_cudnn：Implement with batched gemm and cuDNN
6）tiling-K：Adjust tile size in K dimension (implement 5 GEMMs with tile size 32x32, 64x64, 128x64, 64x128, 128x128 respectively)
7）HGEMM：Implement half precision GEMM and test it with different matrix sizes, which must be multiple of 16. 
8）Tensor_GEMM：Implement tensorcore based GEMM and test it with different matrix sizes, which must be multiple of 16. 
9）google-net_cudnn_hgemm：Implement hgemm for 9 inception modules in Googlenet, add batchGoogleNetInception2 function and it is invoked in main
10）google-net_cudnn_tensor：Implement tensorcore GEMM for 9 inception modules in Googlenet, add batchGoogleNetInception2 function and it is invoked in main

In each folder, there is one Makefile, you can use "make" command to compile it on Ubuntu. Before compilation, you shoule check the environment: 
1) Ubuntu  
2) Nvidia RTX 2080Ti with Cuda 11.0 and cuDNN 8.1.1