#!/bin/bash

for ((thres=1024; thres<=102400000; thres=thres*2))
do
	./gemm 4 $thres >> logT2
done
for ((thres=1024; thres<=102400000; thres=thres*2))
do
	./gemm 8 $thres >> logT2
done
