/**

In this task you will implement the method laplacianFilter of the class Lab2_10 which applies the Laplacian filter on the image.

Implement the isotropic mask for rotations in increments of 45 degrees with a positive weight at the center. Clip all values to be within 0 to 255.

The expected output is provided in the file solution.png.

You may use the following command to check if your output is identical to ours. 

cmp solution.png out.png

If this command has no output, it implies that your solution has produced the same file as ours.

**/

import java.util.Scanner;
public class Lab2_10 {
	public Lab2_10() {
		Img img = new Img("Fig0338.png");
		laplacianFilter(img);
		img.save();
	}
	
	public void laplacianFilter(Img i) {
		//Your code here
		int size = 3;
		int f_mid = (size-1)/2;
		int[] ll_filter = {-1, -1, -1, -1, 8, -1, -1, -1, -1};
		byte[] bak = new byte[i.img.length];
		
		for (int ii = 0; ii < i.img.length; ii++){
			bak[ii] = i.img[ii];
		}
		
		for (int ii = f_mid; ii < i.width - f_mid; ii++)
		{
			for (int ij = f_mid; ij < i.height - f_mid; ij++)
			{
				// backup
				int tmp_value = 0;
				int offset = f_mid*i.width + f_mid;
				
				for (int ki = 0; ki < size; ki++) // row
				{
					for (int kj = 0; kj < size; kj++) // col
					{
						tmp_value += (bak[ij*i.width + ii + kj + ki*i.width - offset]&0xFF) * ll_filter[ki*size + kj];
					}
				}
				
				if (tmp_value > 255) tmp_value = 255;
				if (tmp_value < 0) tmp_value = 0;
				
				//assign value
				i.img[ij*i.width + ii] = (byte)(tmp_value & 0xFF);				
			}
		}
	}
		
	public static void main(String[] args) {
		new Lab2_10();
	}
}
