/**

In this task you will implement the method medianFilter of the class Lab2_9 which applies the median filter on the image. 

You should handle the boundary case by keeping the pixels unchanged. 

The expected output is provided in the files solution3.png and solution7.png, where the digit in the filename is the threshold. 

You may use the following command to check if your output is identical to ours. 

cmp solution7.png out.png

If this command has no output, it implies that your solution has produced the same file as ours.

**/

import java.util.Scanner;
//import java.time.Instant;
//import java.time.Duration;
import java.util.Arrays;
public class Lab2_9 {
	public Lab2_9() {
		Img img = new Img("Fig0441.png");
		System.out.print("Size: ");
		Scanner in = new Scanner(System.in);
		int size = in.nextInt();
		//Instant start = Instant.now();
		medianFilter(img, size);
		//Instant stop = Instant.now();
		//System.out.println("Elapsed time: "+Duration.between(start, stop).toMillis()+"ms");
		img.save();
	}

	public void medianFilter(Img i, int size) {
		//Your code here
		if (size == 1) return;
		
		int offset;
		int f_mid = (size - 1)/2;
		int[] boxvalue = new int[size*size];

		byte[] bak = new byte[i.img.length];
		for (int ii = 0; ii < i.img.length; ii++){
			bak[ii] = i.img[ii];
		}
		
		for (int ii = f_mid; ii < i.width - f_mid; ii++)
		{
			for (int ij = f_mid; ij < i.height - f_mid; ij++)
			{
				// backup // center
				offset = f_mid*i.width + f_mid;
				for (int ki = 0; ki < size; ki++) // row
				{
					for (int kj = 0; kj < size; kj++) // col
					{
						boxvalue[ki*size + kj] = ((int)bak[ij*i.width + ii + kj + ki*i.width - offset]&0xFF);
					}
				}
				
				//sort
				Arrays.sort(boxvalue);
				// mid value
				i.img[ij*i.width + ii] = (byte)(boxvalue[(size*size-1)/2] & 0xFF);				
			}
		}		
	}
		
	public static void main(String[] args) {
		new Lab2_9();
	}
}
