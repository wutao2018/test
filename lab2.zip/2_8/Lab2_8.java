/**

In this task you will implement the method boxFilter of the class Lab2_8 which applies the box smooth filter on the image i. 

To pass the test case you should handle the boundary case by keeping the pixels unchanged. 

The expected output is provided in the files solution3.png and solution7.png, where the digit in the filename is the threshold. 

The solution files are provided for qualitative comparison. Output could be slightly different because of differences in floating point arithmetic. 

**/

import java.util.Scanner;
//import java.time.Instant;
//import java.time.Duration;
public class Lab2_8 {
	public Lab2_8() {
		Img img = new Img("Fig0441.png");
		System.out.print("Size: ");
		Scanner in = new Scanner(System.in);
		int size = in.nextInt();
		//Instant start = Instant.now();
		boxFilter(img, size);
		//Instant stop = Instant.now();
		//System.out.println("Elapsed time: "+Duration.between(start, stop).toMillis()+"ms");
		img.save();
	}
	
	public void boxFilter(Img i, int size) {
		//assume size is odd
		if (size == 1) return;
		
		double bf_value;
		double filtervalue = 1.0/(double)(size*size);
		int f_mid = (size-1)/2;
		
		byte[] bak = new byte[i.img.length];
		for (int ii = 0; ii < i.img.length; ii++){
			bak[ii] = i.img[ii];
		}
		
		//Img img2 = new Img("solution7.png");
		//int max = -2000;
		for (int ii = f_mid; ii < i.width - f_mid; ii++)
		{
			for (int ij = f_mid; ij < i.height - f_mid; ij++)
			{
				bf_value = 0.0;
				int offset = f_mid*i.width + f_mid;
				for (int ki = 0; ki < size; ki++) // row
				{
					for (int kj = 0; kj < size; kj++) // col
					{
						bf_value += (bak[ij*i.width + ii + kj + ki*i.width - offset]&0xFF);
					}
				}
				
				int nr_value = (int)(bf_value*filtervalue);
				i.img[ij*i.width + ii] = (byte)(nr_value & 0xFF);
				//i.img[ij*i.width + ii] = (byte)(Math.abs(i.img[ij*i.width + ii] - img2.img[ij*i.width + ii])&0xFF);
				//if ((i.img[ij*i.width + ii]&0xFF) > max) max = ((int)i.img[ij*i.width + ii]&0xFF);
			}
		}
		//System.out.println("max: " + max);
	}
		
	public static void main(String[] args) {
		new Lab2_8();
	}
}
