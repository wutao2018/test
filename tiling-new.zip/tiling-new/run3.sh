#!/bin/bash

rm -f log
for ((M=64; M<=512; M=M*2))
do
	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null
		./gemm 4 >> log
	done

	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 8 >> log
	done
	
	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 16 >> log
	done

	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 32 >> log
	done	

	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 64 >> log
	done
	
	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 128 >> log
	done

	for ((K=16; K<=512; K=K*2))
	do
		cd ../data
		./gen_data $M $M $K
		cd - > /dev/null	
		./gemm 256 >> log
	done
done
