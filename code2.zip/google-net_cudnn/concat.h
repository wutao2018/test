#ifndef __CONCAT_H__
#define __CONCAT_H__
void concat(int N, int H, int W, int C1, int C2, int C3, int C4,
        float *input1, float *input2, float *input3, float *input4,
        float *buf, float *output);
#endif
