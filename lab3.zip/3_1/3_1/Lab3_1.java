/**

In this task you will implement the Fourier transform and change the image to the Fourier spectrum in the method fourierSpectrum(). Your task is to implement the missing code in the method fourierTransform(). 

Use the log transformation and ensure that all values are in the range 0 ... 255. 

You may use methods declared in the class Complex.java for your convenience. Feel free to add code to Complex.java.

The solution files are provided for qualitative comparison. Output could be different because of differences in floating point arithmetic and differences in the way the rescaling is performed. 

**/

import java.time.Instant;
import java.time.Duration;
public class Lab3_1 {
	public Lab3_1() {
		Img img = new Img("ic128.png");
		Instant start = Instant.now();
		fourierSpectrum(img);
		Instant stop = Instant.now();
		System.out.println("Elapsed time: "+Duration.between(start, stop).getSeconds()+"s");
		img.save();
	}

    public void fourierSpectrum(Img i) {
    	Complex[] F = fourierTransfrom(i);
		double max = Double.NEGATIVE_INFINITY;
		for (int x = 0; x < F.length; x++)
			max = Math.max(F[x].getNorm(), max);
		for (int x = 0; x < i.img.length; x++)
			i.img[x] = (byte)(255 / Math.log(256)*Math.log(255/max*F[x].getNorm()+1));
    }
	

    public Complex[] fourierTransfrom(Img i) {
    	//Change this code
    	Complex[] F = new Complex[i.width*i.height];
		for (int x=0;x<i.img.length;x++){
			F[x] = new Complex();
		}
		
		double tmppix;
		double angle, real, img;
		/*for (int oi = 0; oi < i.width; oi++) {
			for (int oj = 0; oj < i.height; oj++) {
				real = 0.;
				img = 0.;
				for (int ii = 0; ii < i.width; ii++) {
					for (int ij = 0; ij < i.height; ij++) {
						angle = 2*Math.PI*((double)(oi*ii)/(double)(i.width) + (double)(oj*ij)/(double)(i.height));
						tmppix = (double)(i.img[ii*i.width + ij] & 0xFF);
						real += tmppix * Math.cos(angle);
						img += -tmppix * Math.sin(angle);
					}
				}
				
				F[oi*i.width + oj].r = real;
				F[oi*i.width + oj].i = img;
			}
		}  */

		for (int oi = 0; oi < i.img.length; oi++) 
		{
			real = 0.;
			img = 0.;
			int or = oi/i.width;
			int oc = oi%i.width;
			for (int ii = 0; ii < i.img.length; ii++) {
				
				int ir = ii/i.width;
				int ic = ii%i.width;
				angle = 2*Math.PI*((double)(ic*oc)/(double)(i.width) + (double)(or*ir)/(double)(i.height));
				tmppix = (double)(i.img[ii] & 0xFF);
				if ((ir+ic)%2 != 0)
					tmppix = -tmppix;
				real += tmppix * Math.cos(angle);
				img += -tmppix * Math.sin(angle);
			}
			
			F[oi].r = real;
			F[oi].i = img;
		}
		
		return F; 
		
		/* Complex[] F = new Complex[i.width*i.height];
		Complex[] Frow = new Complex[i.width];
		Complex[] Fcol = new Complex[i.height];
		
		for (int x=0;x<i.height;x++)
		{
			for (int y=0;y<i.width;y++)
			{
				Frow[y] = new Complex();
				Frow[y].r = (double)(i.img[x*i.width + y] & 0xFF);
			}
			
			Complex[] rr = Complex.fft(Frow);
			
			for (int y=0;y<i.width;y++)
			{
				F[x*i.width + y] = new Complex();
				F[x*i.width + y] = rr[y];
			}
		}

		for (int x=0; x < i.width; x++)
		{
			for (int y=0; y < i.height; y++)
			{
				Fcol[y] = new Complex();
				Fcol[y] = F[x + y*i.width];
			}
			
			Complex[] cc = Complex.fft(Fcol);
			
			for (int y=0;y<i.height;y++)
			{
				F[x + y*i.width] = cc[y];
			}
		}
		
		//Complex[] out = fft(F);
		
		return F;	*/	
	}
		
	public static void main(String[] args) {
		new Lab3_1();
	}
}
