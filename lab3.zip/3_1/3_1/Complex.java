/**
 * This is a helper class that you may use.
 * If you modify this file, please submit it together with your other solution files.
 */
public final class Complex {
	public double r;
	public double i;
    
	public Complex() {
		this.r = 0;
		this.i = 0;
	}
    
	public Complex(double r, double i) {
		this.r = r;
		this.i = i;
	}
      
	public void plus(Complex op) {
		this.r += op.r;
		this.i += op.i;
	}

	public void minus(Complex op) {
		this.r -= op.r;
		this.i -= op.i;
	}
      
	public void mul(double op) {
		this.r *= op;
		this.i *= op;
	}

	public void mul(Complex op) {
		this.r = this.r * op.r - this.i * op.i;
		this.i = this.r * op.i + this.i * op.r;
	}

	public void div(double op) {
		this.r /= op;
		this.i /= op;
	}

	public Complex plus2(Complex op) {
		Complex tmp = new Complex();
		
		tmp.r = this.r + op.r;
		tmp.i = this.i + op.i;
		
		return tmp;
	}
	
	public Complex minus2(Complex op) {
		Complex tmp = new Complex();
		tmp.r = this.r - op.r;
		tmp.i = this.i - op.i;
		
		return tmp;
	}

	public Complex mul2(Complex op) {
		Complex tmp = new Complex();
		tmp.r = this.r * op.r - this.i * op.i;
		tmp.i = this.r * op.i + this.i * op.r;
		
		return tmp;
	}

	public double getNorm() {
		return Math.sqrt(this.r * this.r + this.i * this.i);
	}
	
	public static Complex[] fft(Complex[] cimg)
	{
		int imlen = cimg.length;
		
		if (1 == imlen) return new Complex[] { cimg[0] };
		
		if (imlen % 2 != 0) { throw new RuntimeException("not a power of 2"); }
		
		// compute FFT of even terms
		Complex[] even = new Complex[imlen/2];
		for (int k = 0; k < imlen/2; k++) {
			even[k] = new Complex();
			even[k] = cimg[2*k];
		}
		Complex[] evenFFT = fft(even);

		// compute FFT of odd terms
		Complex[] odd  = even;  // reuse the array (to avoid n log n space)
		for (int k = 0; k < imlen/2; k++) {
			odd[k] = new Complex();
			odd[k] = cimg[2*k + 1];
		}
		Complex[] oddFFT = fft(odd);

		// combine
		Complex[] y = new Complex[imlen];
		for (int k = 0; k < imlen/2; k++) {
			double kth = -2 * ( k ) * Math.PI / (double)imlen;  // 2d -> 1d
			Complex wk = new Complex(Math.cos(kth), Math.sin(kth));
			
			y[k]       = evenFFT[k].plus2(wk.mul2(oddFFT[k]));
			
			y[k + imlen/2] = evenFFT[k].minus2(wk.mul2(oddFFT[k]));
		}
		
		return y;
	}	
}

