/**

In this task you will implement the inverse Fourier transform and perform filtering in the frequency domain. You should reuse your implementation of the Fourier transform from the previous lab session (3_1). 

In the filterImage() method add one line of code that changes the Fourier transformed image such that it is 0 at the center.

Implement the inverse Fourier transform in the method inverseFourierTransfrom().

You may use methods declared in the class Complex.java for your convenience.  Feel free to add code to Complex.java.

The solution files are provided for qualitative comparison. Output could be different because of differences in floating point arithmetic and differences in the way the re-scaling is performed. 

**/

import java.time.Instant;
import java.time.Duration;
public class Lab3_2 {
	public Lab3_2() {
		Img img = new Img("ic128.png");
		Instant start = Instant.now();
		filterImage(img);
		Instant stop = Instant.now();
		System.out.println("Elapsed time: "+Duration.between(start, stop).getSeconds()+"s");
		img.save();
	}

    public void filterImage(Img i) {
		Complex[] F = fourierTransfrom(i);
		//Your code here
		F[i.img.length/2 + i.width/2].r = 0.f; // = new Complex();  // dc term
		F[i.img.length/2 + i.width/2].i = 0.f;
		inverseFourierTransfrom(F, i);
    }

    public Complex[] fourierTransfrom(Img i) {
    	//Change this to your code from 3_1
    	Complex[] F = new Complex[i.width*i.height];
		for (int x=0;x<i.img.length;x++){
			F[x] = new Complex();
		}
		
		double tmppix;
		double angle, real, img;
		/*for (int oi = 0; oi < i.width; oi++) {
			for (int oj = 0; oj < i.height; oj++) {
				real = 0.;
				img = 0.;
				for (int ii = 0; ii < i.width; ii++) {
					for (int ij = 0; ij < i.height; ij++) {
						angle = 2*Math.PI*((double)(oi*ii)/(double)(i.width) + (double)(oj*ij)/(double)(i.height));
						tmppix = (double)(i.img[ii*i.width + ij] & 0xFF);
						real += tmppix * Math.cos(angle);
						img += -tmppix * Math.sin(angle);
					}
				}
				
				F[oi*i.width + oj].r = real;
				F[oi*i.width + oj].i = img;
			}
		}*/

		for (int oi = 0; oi < i.img.length; oi++) 
		{
			real = 0.;
			img = 0.;
			int or = oi/i.width;
			int oc = oi%i.width;
			for (int ii = 0; ii < i.img.length; ii++) {
				
				int ir = ii/i.width;
				int ic = ii%i.width;
				angle = 2*Math.PI*((double)(ic*oc)/(double)(i.width) + (double)(or*ir)/(double)(i.height));
				tmppix = (double)(i.img[ii] & 0xFF);
				if ((ir+ic)%2 != 0)
					tmppix = -tmppix;
				real += tmppix * Math.cos(angle);
				img += -tmppix * Math.sin(angle);
			}
			
			F[oi].r = real;
			F[oi].i = img;
		}
		
		return F;
	}

	private void inverseFourierTransfrom(Complex[] F, Img i) {
		//Your code here
		//Img img2 = new Img("ic128Solution.png");  // "ic128Solution.png"
		double real, im, angle;
		Complex cplx;
		int or, oc, ir, ic;
		
		/*double min, max;
		min = 0.;
		max = 0.;
		for (int oi = 0; oi < i.img.length; oi++) 
		{
			real = 0.;
			im = 0.;
			or = oi/i.width;
			oc = oi%i.width;
			for (int ii = 0; ii < i.img.length; ii++)
			{
				ir = ii/i.width;
				ic = ii%i.width;
				angle = 2*Math.PI*((double)(ic*oc)/(double)(i.width) + (double)(or*ir)/(double)(i.height));
				//cplx = F[ii];
				real += F[ii].r * Math.cos(angle) - F[ii].i * Math.sin(angle);
				im += F[ii].r * Math.sin(angle) + F[ii].i * Math.cos(angle);
			}
			
			real = Math.sqrt(real*real + im*im);
			real = real/(double)(i.img.length);
			
			i.img[oi] = (byte)(((int)real) & 0xFF);  // rescaling
			
			//real = Math.abs(((int)i.img[oi]&0xFF) - ((int)img2.img[oi]&0xFF));
			//if (real > max) max = real;
			//i.img[oi] = (byte)((int)(Math.abs(i.img[oi] - img2.img[oi])));
		}
		System.out.println("max: "+ max);*/
		
		
		for (int oi = 0; oi < i.width; oi++) {
			for (int oj = 0; oj < i.height; oj++) {
				real = 0.;
				im = 0.;
				for (int ii = 0; ii < i.width; ii++) {
					for (int ij = 0; ij < i.height; ij++) {
						angle = 2*Math.PI*((double)(oi*ii)/(double)(i.width) + (double)(oj*ij)/(double)(i.height));
						
						real += F[ij*i.width + ii].r * Math.cos(angle) - F[ij*i.width + ii].i * Math.sin(angle);
						im += F[ij*i.width + ii].r * Math.sin(angle) + F[ij*i.width + ii].i * Math.cos(angle);						
					}
				}
				
				real = Math.sqrt(real*real + im*im);
				real = real/(double)(i.img.length);
				i.img[oj*i.width + oi] = (byte)(((int)real) & 0xFF);
			}
		}
	}

	public static void main(String[] args) {
		new Lab3_2();
	}
}
